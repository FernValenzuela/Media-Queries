# Lesson plan
  
---

```
@media (min-width: 600px) {
  .cardGrid {
    grid-template-columns: repeat(2, 1fr)
  }
}

@media (min-width: 1000px) {
  .cardGrid {
    grid-template-columns: repeat(4, 1fr)
  }
}
```